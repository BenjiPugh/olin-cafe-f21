# HW 4 Verilog Section
